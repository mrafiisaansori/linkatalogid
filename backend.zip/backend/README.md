# Linkatalog Backend (PHP REST API)

REST API untuk seluruh operasi data Linkatalog. Frontend Next.js memanggil endpoint di sini lewat HTTPS dengan Basic Auth.

- Stack: PHP 8.2+, MySQL 5.7/8+, Apache atau Nginx dengan rewrite ke `index.php`
- Hosting target: `https://linkatalog.raftechsolution.web.id`
- Auth backend: `Authorization: Basic base64(admin:Indones!4)`

## Setup hosting

1. Upload isi folder `backend/` ke document root subdomain.
2. Pastikan rewrite aktif.
3. Import `schema.sql`.
4. Kalau database sudah terlanjur live, jalankan juga `migration-email-verification.sql`.
5. Pastikan `config.php` terisi DB, Basic Auth, dan SMTP.
6. Jalankan `php seed.php` untuk membuat admin `admin / Indones!4`.

## SMTP

Verifikasi email seller memakai SMTP:

- Host: `mail.raftechsolution.web.id`
- Port: `465`
- Security: `SSL`
- Username: `linkatalog@raftechsolution.web.id`

## Endpoint utama

| Method | Path | Catatan |
| --- | --- | --- |
| GET | `/health` | Healthcheck |
| GET | `/auth/check-username` | Cek username katalog |
| POST | `/auth/sign-up` | Daftar seller, kirim kode verifikasi |
| POST | `/auth/sign-in` | Login seller |
| POST | `/auth/verify-email` | Verifikasi kode email |
| POST | `/auth/resend-verification` | Kirim ulang kode |
| GET | `/me` | Ambil sesi seller |
| PUT/PATCH | `/me/{userId}/profile` | Update profil |
| GET/POST | `/me/{userId}/products` | List / tambah produk |
| PUT/PATCH/DELETE | `/me/{userId}/products/{productId}` | Ubah / hapus produk |
| POST | `/me/{userId}/products/{productId}/toggle` | Toggle aktif |
| GET | `/public/catalog/{username}` | Katalog publik |
| POST | `/analytics/track` | Simpan event analytics |
| POST | `/admin/auth/login` | Login admin |
| GET | `/admin/dashboard` | Dashboard admin |
| GET | `/admin/analytics` | Analytics admin |
| GET | `/admin/users` | Daftar seller |
| GET | `/admin/users/{userId}/detail` | Detail seller |
| PATCH | `/admin/users/{userId}/status` | Ubah status seller |
| GET | `/admin/products` | Daftar produk |
| GET/POST | `/admin/audit-logs` | Ambil / simpan audit log |

## Catatan

- HTTPS wajib karena backend memakai Basic Auth.
- Setelah deploy pertama, sebaiknya ganti password admin dan password Basic Auth.
- Folder `backend/` memang tidak di-push ke git.
