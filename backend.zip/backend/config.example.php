<?php
// Copy ke config.php dan isi dengan kredensial production.
// File config.php TIDAK boleh di-commit (sudah masuk .gitignore).

return [
    'db' => [
        'host'     => 'localhost',
        'port'     => 3306,
        'database' => 'raftechs_linkatalog',
        'user'     => 'raftechs_linkatalog',
        'password' => 'REDACTED',
        'charset'  => 'utf8mb4',
    ],
    'basic_auth' => [
        'username' => 'admin',
        'password' => 'REDACTED',
    ],
    'smtp' => [
        'host' => 'mail.example.com',
        'port' => 465,
        'secure' => 'ssl',
        'username' => 'no-reply@example.com',
        'password' => 'REDACTED',
        'from_email' => 'no-reply@example.com',
        'from_name' => 'Linkatalog',
    ],
    // Allow CORS dari domain frontend Vercel. Set null kalau backend hanya
    // dipanggil server-to-server (Next.js route → PHP).
    'cors_origin' => null,
    // Set ke false di production.
    'debug' => false,
];
