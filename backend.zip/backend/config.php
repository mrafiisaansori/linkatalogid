<?php
// Production config — JANGAN COMMIT ke git.
// File ini sudah di-ignore via .gitignore.

return [
    'db' => [
        'host'     => 'localhost',
        'port'     => 3306,
        'database' => 'raftechs_linkatalog',
        'user'     => 'raftechs_linkatalog',
        'password' => 'Indones!4_Raya',
        'charset'  => 'utf8mb4',
    ],
    'basic_auth' => [
        'username' => 'admin',
        'password' => 'Indones!4',
    ],
    'smtp' => [
        'host' => 'mail.raftechsolution.web.id',
        'port' => 465,
        'secure' => 'ssl',
        'username' => 'linkatalog@raftechsolution.web.id',
        'password' => 'Indones!4_Raya',
        'from_email' => 'linkatalog@raftechsolution.web.id',
        'from_name' => 'Linkatalog',
    ],
    'cors_origin' => null,
    'debug' => false,
];
