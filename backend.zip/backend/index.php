<?php
declare(strict_types=1);

require_once __DIR__ . '/src/Bootstrap.php';
\Linkatalog\Bootstrap::init(__DIR__ . '/config.php');

use Linkatalog\Auth;
use Linkatalog\Http;
use Linkatalog\Controllers\AdminController;
use Linkatalog\Controllers\AnalyticsController;
use Linkatalog\Controllers\AuthController;
use Linkatalog\Controllers\MeController;
use Linkatalog\Controllers\PublicController;

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    Http::corsHeaders();
    http_response_code(204);
    exit;
}

Auth::requireBasic();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
$path = preg_replace('#^/index\.php#', '', $path) ?? $path;
$path = preg_replace('#^/api#', '', $path) ?? $path;
$path = '/' . ltrim($path, '/');
$path = rtrim($path, '/');
if ($path === '') $path = '/';

if ($path === '/' || $path === '/health') {
    Http::json(['success' => true, 'service' => 'linkatalog-backend', 'time' => \Linkatalog\Utils::nowIso()]);
}

if ($method === 'GET'  && $path === '/auth/check-username')    AuthController::checkUsername();
if ($method === 'POST' && $path === '/auth/sign-up')           AuthController::signUp();
if ($method === 'POST' && $path === '/auth/sign-in')           AuthController::signIn();
if ($method === 'POST' && $path === '/auth/verify-email')      AuthController::verifyEmail();
if ($method === 'POST' && $path === '/auth/resend-verification') AuthController::resendVerification();

if ($method === 'GET'  && $path === '/me')                     MeController::me();

if (preg_match('#^/me/([^/]+)/profile$#', $path, $m) && in_array($method, ['PUT', 'PATCH'], true)) MeController::updateProfile($m[1]);
if (preg_match('#^/me/([^/]+)/products$#', $path, $m)) {
    if ($method === 'GET')  MeController::listProducts($m[1]);
    if ($method === 'POST') MeController::createProduct($m[1]);
}
if (preg_match('#^/me/([^/]+)/products/([^/]+)$#', $path, $m)) {
    if ($method === 'PUT' || $method === 'PATCH') MeController::updateProduct($m[1], $m[2]);
    if ($method === 'DELETE')                     MeController::deleteProduct($m[1], $m[2]);
}
if (preg_match('#^/me/([^/]+)/products/([^/]+)/toggle$#', $path, $m) && in_array($method, ['POST', 'PATCH'], true)) MeController::toggleProduct($m[1], $m[2]);

if (preg_match('#^/public/catalog/([^/]+)$#', $path, $m) && $method === 'GET') PublicController::catalog($m[1]);

if ($path === '/analytics/track' && $method === 'POST') AnalyticsController::track();

if ($path === '/admin/auth/login' && $method === 'POST') AdminController::login();
if (preg_match('#^/admin/users/([^/]+)/status$#', $path, $m) && in_array($method, ['PATCH', 'PUT'], true)) AdminController::setUserStatus($m[1]);
if ($path === '/admin/users' && $method === 'GET') AdminController::listUsers();
if (preg_match('#^/admin/users/([^/]+)/detail$#', $path, $m) && $method === 'GET') AdminController::userDetail($m[1]);
if ($path === '/admin/products' && $method === 'GET') AdminController::listProducts();
if ($path === '/admin/dashboard' && $method === 'GET') AdminController::dashboard();
if ($path === '/admin/analytics' && $method === 'GET') AdminController::analytics();
if ($path === '/admin/audit-logs' && $method === 'GET') AdminController::listAuditLogs();
if ($path === '/admin/audit-logs' && $method === 'POST') AdminController::createAuditLog();
if (preg_match('#^/admin/([^/]+)$#', $path, $m) && $method === 'GET') AdminController::getAdmin($m[1]);

Http::fail('Route not found.', 404, ['method' => $method, 'path' => $path]);
