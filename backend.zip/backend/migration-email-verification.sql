ALTER TABLE `UserAccount`
  ADD COLUMN `emailVerifiedAt` DATETIME(3) NULL AFTER `passwordHash`,
  ADD COLUMN `verificationCode` VARCHAR(16) NULL AFTER `emailVerifiedAt`,
  ADD COLUMN `verificationExpiresAt` DATETIME(3) NULL AFTER `verificationCode`,
  ADD COLUMN `verificationSentAt` DATETIME(3) NULL AFTER `verificationExpiresAt`;

CREATE INDEX `UserAccount_verificationCode_idx` ON `UserAccount` (`verificationCode`);

UPDATE `UserAccount`
SET
  `emailVerifiedAt` = COALESCE(`emailVerifiedAt`, `createdAt`),
  `verificationCode` = NULL,
  `verificationExpiresAt` = NULL,
  `verificationSentAt` = NULL
WHERE `emailVerifiedAt` IS NULL;
