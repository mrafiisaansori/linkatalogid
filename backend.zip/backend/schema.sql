-- Linkatalog MySQL schema
-- Database: raftechs_linkatalog
-- Charset: utf8mb4, engine: InnoDB

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `AuditLog`;
DROP TABLE IF EXISTS `AnalyticsEvent`;
DROP TABLE IF EXISTS `Product`;
DROP TABLE IF EXISTS `UserAccount`;
DROP TABLE IF EXISTS `User`;
DROP TABLE IF EXISTS `AdminLoginRateLimit`;
DROP TABLE IF EXISTS `AdminUser`;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `User` (
  `id`              VARCHAR(32)  NOT NULL,
  `name`            VARCHAR(255) NOT NULL,
  `username`        VARCHAR(64)  NOT NULL,
  `bio`             TEXT         NOT NULL,
  `whatsapp`        VARCHAR(32)  NOT NULL DEFAULT '',
  `profileImage`    VARCHAR(512) NOT NULL DEFAULT '',
  `location`        VARCHAR(255) NOT NULL DEFAULT '',
  `themePreference` VARCHAR(16)  NOT NULL DEFAULT 'light',
  `themeAccent`     VARCHAR(32)  NOT NULL DEFAULT 'emerald',
  `isActive`        TINYINT(1)   NOT NULL DEFAULT 1,
  `createdAt`       DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt`       DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_username_key` (`username`),
  KEY `User_createdAt_idx` (`createdAt`),
  KEY `User_isActive_idx` (`isActive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `UserAccount` (
  `id`           VARCHAR(32)  NOT NULL,
  `userId`       VARCHAR(32)  NOT NULL,
  `email`        VARCHAR(255) NOT NULL,
  `passwordHash` VARCHAR(255) NOT NULL,
  `emailVerifiedAt` DATETIME(3) NULL,
  `verificationCode` VARCHAR(16) NULL,
  `verificationExpiresAt` DATETIME(3) NULL,
  `verificationSentAt` DATETIME(3) NULL,
  `createdAt`    DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt`    DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserAccount_userId_key` (`userId`),
  UNIQUE KEY `UserAccount_email_key` (`email`),
  KEY `UserAccount_verificationCode_idx` (`verificationCode`),
  CONSTRAINT `UserAccount_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Product` (
  `id`          VARCHAR(64)  NOT NULL,
  `userId`      VARCHAR(32)  NOT NULL,
  `title`       VARCHAR(255) NOT NULL,
  `price`       INT          NOT NULL,
  `description` TEXT         NOT NULL,
  `imageUrl`    VARCHAR(512) NOT NULL,
  `badge`       VARCHAR(64)  NOT NULL DEFAULT '',
  `category`    VARCHAR(128) NOT NULL DEFAULT '',
  `isActive`    TINYINT(1)   NOT NULL DEFAULT 1,
  `createdAt`   DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt`   DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Product_userId_idx` (`userId`),
  KEY `Product_createdAt_idx` (`createdAt`),
  KEY `Product_isActive_idx` (`isActive`),
  KEY `Product_category_idx` (`category`),
  CONSTRAINT `Product_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `AdminUser` (
  `id`           VARCHAR(32)  NOT NULL,
  `username`     VARCHAR(64)  NOT NULL,
  `passwordHash` VARCHAR(255) NOT NULL,
  `role`         VARCHAR(32)  NOT NULL DEFAULT 'superadmin',
  `isActive`     TINYINT(1)   NOT NULL DEFAULT 1,
  `createdAt`    DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt`    DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `AdminUser_username_key` (`username`),
  KEY `AdminUser_isActive_idx` (`isActive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `AnalyticsEvent` (
  `id`          VARCHAR(32)  NOT NULL,
  `eventType`   ENUM('PAGE_VIEW','PRODUCT_VIEW','WHATSAPP_CLICK') NOT NULL,
  `ownerUserId` VARCHAR(32)  NOT NULL,
  `productId`   VARCHAR(64)  NULL,
  `path`        VARCHAR(255) NOT NULL,
  `referrer`    VARCHAR(512) NULL,
  `userAgent`   VARCHAR(512) NULL,
  `ipHash`      VARCHAR(128) NULL,
  `createdAt`   DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `AnalyticsEvent_owner_event_created_idx` (`ownerUserId`, `eventType`, `createdAt`),
  KEY `AnalyticsEvent_product_event_created_idx` (`productId`, `eventType`, `createdAt`),
  KEY `AnalyticsEvent_createdAt_idx` (`createdAt`),
  CONSTRAINT `AnalyticsEvent_ownerUserId_fkey` FOREIGN KEY (`ownerUserId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AnalyticsEvent_productId_fkey`   FOREIGN KEY (`productId`)   REFERENCES `Product`(`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `AuditLog` (
  `id`          VARCHAR(32)  NOT NULL,
  `adminUserId` VARCHAR(32)  NOT NULL,
  `action`      VARCHAR(128) NOT NULL,
  `targetType`  VARCHAR(64)  NOT NULL,
  `targetId`    VARCHAR(64)  NOT NULL,
  `metadata`    JSON         NULL,
  `createdAt`   DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `AuditLog_admin_createdAt_idx` (`adminUserId`, `createdAt`),
  KEY `AuditLog_target_idx` (`targetType`, `targetId`),
  KEY `AuditLog_action_createdAt_idx` (`action`, `createdAt`),
  CONSTRAINT `AuditLog_adminUserId_fkey` FOREIGN KEY (`adminUserId`) REFERENCES `AdminUser`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `AdminLoginRateLimit` (
  `id`           VARCHAR(32)  NOT NULL,
  `identifier`   VARCHAR(128) NOT NULL,
  `attempts`     INT          NOT NULL DEFAULT 0,
  `windowStart`  DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `blockedUntil` DATETIME(3)  NULL,
  `createdAt`    DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt`    DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `AdminLoginRateLimit_identifier_key` (`identifier`),
  KEY `AdminLoginRateLimit_blockedUntil_idx` (`blockedUntil`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
