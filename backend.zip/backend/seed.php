<?php
declare(strict_types=1);

/**
 * Seed admin user. Jalankan sekali setelah `mysql < schema.sql`.
 * Usage (di server hosting):
 *   php seed.php
 */

require_once __DIR__ . '/src/Bootstrap.php';
\Linkatalog\Bootstrap::init(__DIR__ . '/config.php');

use Linkatalog\Db;
use Linkatalog\Utils;

$username = 'admin';
$password = 'Indones!4';
$pdo = Db::pdo();

$stmt = $pdo->prepare('SELECT id FROM `AdminUser` WHERE username = ? LIMIT 1');
$stmt->execute([$username]);
$existing = $stmt->fetch();

$hash = Utils::hashPassword($password);

if ($existing) {
    $upd = $pdo->prepare('UPDATE `AdminUser` SET `passwordHash` = ?, `role` = ?, `isActive` = 1 WHERE id = ?');
    $upd->execute([$hash, 'superadmin', $existing['id']]);
    echo "Admin user '{$username}' updated.\n";
} else {
    $ins = $pdo->prepare('INSERT INTO `AdminUser` (`id`, `username`, `passwordHash`, `role`, `isActive`) VALUES (?, ?, ?, ?, 1)');
    $ins->execute([Utils::id(), $username, $hash, 'superadmin']);
    echo "Admin user '{$username}' created.\n";
}

echo "Default login: {$username} / {$password} — ganti via SQL setelah login pertama.\n";
