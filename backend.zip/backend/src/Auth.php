<?php
declare(strict_types=1);

namespace Linkatalog;

final class Auth
{
    /**
     * Enforce HTTP Basic Auth menggunakan kredensial dari config.
     * Setiap request ke API wajib menyertakan header Authorization: Basic <base64>.
     */
    public static function requireBasic(): void
    {
        $cfg = Bootstrap::get('basic_auth', []);
        $expectedUser = (string) ($cfg['username'] ?? '');
        $expectedPass = (string) ($cfg['password'] ?? '');

        if ($expectedUser === '' || $expectedPass === '') {
            Http::json(['success' => false, 'message' => 'Server auth misconfigured.'], 500);
        }

        $user = $_SERVER['PHP_AUTH_USER'] ?? null;
        $pass = $_SERVER['PHP_AUTH_PW'] ?? null;

        // Fallback untuk environment yang tidak otomatis populate PHP_AUTH_*
        if ($user === null || $pass === null) {
            $header = $_SERVER['HTTP_AUTHORIZATION']
                ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
                ?? '';
            if (str_starts_with($header, 'Basic ')) {
                $decoded = base64_decode(substr($header, 6), true);
                if ($decoded !== false && str_contains($decoded, ':')) {
                    [$user, $pass] = explode(':', $decoded, 2);
                }
            }
        }

        if (!is_string($user) || !is_string($pass)
            || !hash_equals($expectedUser, $user)
            || !hash_equals($expectedPass, $pass)) {
            header('WWW-Authenticate: Basic realm="linkatalog"');
            Http::json(['success' => false, 'message' => 'Unauthorized.'], 401);
        }
    }
}
