<?php
declare(strict_types=1);

namespace Linkatalog;

final class Bootstrap
{
    public static array $config = [];

    public static function init(string $configPath): void
    {
        if (!is_file($configPath)) {
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Server config missing.']);
            exit;
        }

        self::$config = require $configPath;

        if (!empty(self::$config['debug'])) {
            ini_set('display_errors', '1');
            error_reporting(E_ALL);
        } else {
            ini_set('display_errors', '0');
            error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
        }

        // Class autoloader sederhana untuk namespace Linkatalog\
        spl_autoload_register(static function (string $class): void {
            if (!str_starts_with($class, 'Linkatalog\\')) {
                return;
            }
            $relative = substr($class, strlen('Linkatalog\\'));
            $path = __DIR__ . '/' . str_replace('\\', '/', $relative) . '.php';
            if (is_file($path)) {
                require_once $path;
            }
        });
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return self::$config[$key] ?? $default;
    }
}
