<?php
declare(strict_types=1);

namespace Linkatalog\Controllers;

use Linkatalog\Db;
use Linkatalog\Http;
use Linkatalog\Utils;

final class AdminController
{
    public static function login(): never
    {
        $b = Http::body();
        $username = strtolower(trim((string) ($b['username'] ?? '')));
        $password = (string) ($b['password'] ?? '');
        if ($username === '' || trim($password) === '') {
            Http::fail('Username dan password wajib diisi.', 400);
        }

        $stmt = Db::pdo()->prepare('SELECT id, username, passwordHash, role, isActive, createdAt, updatedAt FROM `AdminUser` WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if (!$admin || (int) $admin['isActive'] !== 1) {
            Http::fail('Username atau password admin belum cocok.', 401);
        }
        if (!Utils::verifyPassword($password, $admin['passwordHash'])) {
            Http::fail('Username atau password admin belum cocok.', 401);
        }

        self::writeAuditLogSafe(
            $admin['id'],
            'login_admin',
            'admin_user',
            $admin['id'],
            ['username' => $admin['username']]
        );

        Http::json([
            'success' => true,
            'admin' => self::serializeAdmin($admin),
        ]);
    }

    public static function getAdmin(string $id): never
    {
        $stmt = Db::pdo()->prepare('SELECT id, username, role, isActive, createdAt, updatedAt FROM `AdminUser` WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $admin = $stmt->fetch();
        if (!$admin) {
            Http::fail('Admin not found.', 404);
        }
        Http::json(['success' => true, 'admin' => self::serializeAdmin($admin)]);
    }

    public static function setUserStatus(string $userId): never
    {
        $b = Http::body();
        $isActive = !empty($b['isActive']) ? 1 : 0;

        $stmt = Db::pdo()->prepare('UPDATE `User` SET `isActive` = ? WHERE id = ?');
        $stmt->execute([$isActive, $userId]);
        if ($stmt->rowCount() === 0) {
            Http::fail('User tidak ditemukan.', 404);
        }

        $adminUserId = trim((string) ($b['adminUserId'] ?? ''));
        if ($adminUserId !== '') {
            self::writeAuditLogSafe(
                $adminUserId,
                'set_user_status',
                'user',
                $userId,
                [
                    'isActive' => $isActive === 1,
                    'adminUsername' => trim((string) ($b['adminUsername'] ?? '')),
                ]
            );
        }

        Http::json(['success' => true]);
    }

    public static function listUsers(): never
    {
        $query = trim((string) (Http::query('query', '') ?? ''));
        $status = trim((string) (Http::query('status', 'all') ?? 'all'));

        $where = [];
        $params = [];

        if ($status === 'active') {
            $where[] = 'u.isActive = 1';
        } elseif ($status === 'inactive') {
            $where[] = 'u.isActive = 0';
        }

        if ($query !== '') {
            $where[] = '(u.name LIKE ? OR u.username LIKE ? OR COALESCE(ua.email, \'\') LIKE ? OR u.whatsapp LIKE ?)';
            $term = '%' . $query . '%';
            array_push($params, $term, $term, $term, $term);
        }

        $sql = 'SELECT
            u.id, u.name, u.username, u.bio, u.whatsapp, u.profileImage, u.location,
            u.themePreference, u.themeAccent, u.isActive, u.createdAt, u.updatedAt,
            ua.email,
            COALESCE(pc.productCount, 0) AS productCount,
            COALESCE(ast.views, 0) AS views,
            COALESCE(ast.whatsappClicks, 0) AS whatsappClicks
            FROM `User` u
            LEFT JOIN `UserAccount` ua ON ua.userId = u.id
            LEFT JOIN (
                SELECT userId, COUNT(*) AS productCount
                FROM `Product`
                GROUP BY userId
            ) pc ON pc.userId = u.id
            LEFT JOIN (
                SELECT ownerUserId,
                    SUM(CASE WHEN eventType = \'PAGE_VIEW\' THEN 1 ELSE 0 END) AS views,
                    SUM(CASE WHEN eventType = \'WHATSAPP_CLICK\' THEN 1 ELSE 0 END) AS whatsappClicks
                FROM `AnalyticsEvent`
                GROUP BY ownerUserId
            ) ast ON ast.ownerUserId = u.id';

        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY u.createdAt DESC';

        $stmt = Db::pdo()->prepare($sql);
        $stmt->execute($params);
        $rows = array_map([self::class, 'serializeUserListItem'], $stmt->fetchAll());

        Http::json([
            'success' => true,
            'data' => $rows,
        ]);
    }

    public static function listProducts(): never
    {
        $query = trim((string) (Http::query('query', '') ?? ''));
        $status = trim((string) (Http::query('status', 'all') ?? 'all'));

        $where = [];
        $params = [];

        if ($status === 'active') {
            $where[] = 'p.isActive = 1';
        } elseif ($status === 'inactive') {
            $where[] = 'p.isActive = 0';
        }

        if ($query !== '') {
            $where[] = '(p.title LIKE ? OR p.category LIKE ? OR u.name LIKE ? OR u.username LIKE ?)';
            $term = '%' . $query . '%';
            array_push($params, $term, $term, $term, $term);
        }

        $sql = 'SELECT
            p.*,
            u.name AS ownerName,
            u.username AS ownerUsername,
            COALESCE(pv.views, 0) AS views,
            COALESCE(wc.clicks, 0) AS clicks
            FROM `Product` p
            INNER JOIN `User` u ON u.id = p.userId
            LEFT JOIN (
                SELECT productId, COUNT(*) AS views
                FROM `AnalyticsEvent`
                WHERE eventType = \'PRODUCT_VIEW\' AND productId IS NOT NULL
                GROUP BY productId
            ) pv ON pv.productId = p.id
            LEFT JOIN (
                SELECT productId, COUNT(*) AS clicks
                FROM `AnalyticsEvent`
                WHERE eventType = \'WHATSAPP_CLICK\' AND productId IS NOT NULL
                GROUP BY productId
            ) wc ON wc.productId = p.id';

        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY p.createdAt DESC';

        $stmt = Db::pdo()->prepare($sql);
        $stmt->execute($params);
        $rows = array_map([self::class, 'serializeProductListItem'], $stmt->fetchAll());

        Http::json([
            'success' => true,
            'data' => $rows,
        ]);
    }

    public static function dashboard(): never
    {
        $pdo = Db::pdo();

        $totals = [
            'users' => (int) $pdo->query('SELECT COUNT(*) FROM `User`')->fetchColumn(),
            'catalogs' => (int) $pdo->query('SELECT COUNT(*) FROM `User` WHERE isActive = 1')->fetchColumn(),
            'products' => (int) $pdo->query('SELECT COUNT(*) FROM `Product`')->fetchColumn(),
            'whatsappClicks' => 0,
            'pageViews' => 0,
        ];

        $eventTotalsStmt = $pdo->query('SELECT eventType, COUNT(*) AS cnt
            FROM `AnalyticsEvent`
            WHERE eventType IN (\'PAGE_VIEW\', \'WHATSAPP_CLICK\')
            GROUP BY eventType');
        foreach ($eventTotalsStmt->fetchAll() as $row) {
            if ($row['eventType'] === 'PAGE_VIEW') {
                $totals['pageViews'] = (int) $row['cnt'];
            }
            if ($row['eventType'] === 'WHATSAPP_CLICK') {
                $totals['whatsappClicks'] = (int) $row['cnt'];
            }
        }

        $recentUsersStmt = $pdo->query('SELECT u.*, ua.email
            FROM `User` u
            LEFT JOIN `UserAccount` ua ON ua.userId = u.id
            ORDER BY u.createdAt DESC
            LIMIT 5');
        $recentUsers = array_map([MeController::class, 'serializeUser'], $recentUsersStmt->fetchAll());

        $recentProductsStmt = $pdo->query('SELECT p.*, u.name AS ownerName, u.username AS ownerUsername
            FROM `Product` p
            INNER JOIN `User` u ON u.id = p.userId
            ORDER BY p.createdAt DESC
            LIMIT 5');
        $recentProducts = array_map([MeController::class, 'serializeProduct'], $recentProductsStmt->fetchAll());

        $topCatalogsStmt = $pdo->query('SELECT
            u.id, u.name, u.username, u.bio, u.whatsapp, u.profileImage, u.location,
            u.themePreference, u.themeAccent, u.isActive, u.createdAt, u.updatedAt,
            ua.email,
            COUNT(ae.id) AS views
            FROM `AnalyticsEvent` ae
            INNER JOIN `User` u ON u.id = ae.ownerUserId
            LEFT JOIN `UserAccount` ua ON ua.userId = u.id
            WHERE ae.eventType = \'PAGE_VIEW\'
            GROUP BY
                u.id, u.name, u.username, u.bio, u.whatsapp, u.profileImage, u.location,
                u.themePreference, u.themeAccent, u.isActive, u.createdAt, u.updatedAt, ua.email
            ORDER BY views DESC, u.createdAt DESC
            LIMIT 5');
        $topCatalogs = array_map(
            static fn(array $row): array => [
                'user' => MeController::serializeUser($row),
                'views' => (int) $row['views'],
            ],
            $topCatalogsStmt->fetchAll()
        );

        $topProductsStmt = $pdo->query('SELECT
            p.*,
            u.name AS ownerName,
            u.username AS ownerUsername,
            COUNT(ae.id) AS clicks
            FROM `AnalyticsEvent` ae
            INNER JOIN `Product` p ON p.id = ae.productId
            INNER JOIN `User` u ON u.id = p.userId
            WHERE ae.eventType = \'WHATSAPP_CLICK\' AND ae.productId IS NOT NULL
            GROUP BY
                p.id, p.userId, p.title, p.price, p.description, p.imageUrl, p.badge,
                p.category, p.isActive, p.createdAt, p.updatedAt, u.name, u.username
            ORDER BY clicks DESC, p.createdAt DESC
            LIMIT 5');
        $topProducts = array_map(
            static fn(array $row): array => [
                'product' => MeController::serializeProduct($row),
                'clicks' => (int) $row['clicks'],
            ],
            $topProductsStmt->fetchAll()
        );

        Http::json([
            'success' => true,
            'data' => [
                'totals' => $totals,
                'recentUsers' => $recentUsers,
                'recentProducts' => $recentProducts,
                'topCatalogs' => $topCatalogs,
                'topProducts' => $topProducts,
            ],
        ]);
    }

    public static function analytics(): never
    {
        $days = self::normalizeDays(Http::query('days', '14'));
        $periodSql = 'DATE_SUB(UTC_TIMESTAMP(), INTERVAL ' . $days . ' DAY)';
        $pdo = Db::pdo();

        $dailyStmt = $pdo->query('SELECT
            DATE(createdAt) AS day,
            SUM(CASE WHEN eventType = \'PAGE_VIEW\' THEN 1 ELSE 0 END) AS pageViews,
            SUM(CASE WHEN eventType = \'WHATSAPP_CLICK\' THEN 1 ELSE 0 END) AS whatsappClicks
            FROM `AnalyticsEvent`
            WHERE createdAt >= ' . $periodSql . '
            GROUP BY DATE(createdAt)
            ORDER BY day ASC');

        $pageViewsPerDay = [];
        $whatsappClicksPerDay = [];
        foreach ($dailyStmt->fetchAll() as $row) {
            $day = (string) $row['day'];
            $pageViewsPerDay[$day] = (int) $row['pageViews'];
            $whatsappClicksPerDay[$day] = (int) $row['whatsappClicks'];
        }

        $topReferrersStmt = $pdo->query('SELECT referrer, COUNT(*) AS cnt
            FROM `AnalyticsEvent`
            WHERE createdAt >= ' . $periodSql . ' AND referrer IS NOT NULL AND referrer <> \'\'
            GROUP BY referrer
            ORDER BY cnt DESC, referrer ASC
            LIMIT 10');
        $topReferrers = array_map(
            static fn(array $row): array => [
                'referrer' => (string) $row['referrer'],
                'count' => (int) $row['cnt'],
            ],
            $topReferrersStmt->fetchAll()
        );

        $topCatalogsStmt = $pdo->query('SELECT
            u.id AS userId,
            u.name,
            u.username,
            COUNT(ae.id) AS cnt
            FROM `AnalyticsEvent` ae
            INNER JOIN `User` u ON u.id = ae.ownerUserId
            WHERE ae.createdAt >= ' . $periodSql . ' AND ae.eventType = \'PAGE_VIEW\'
            GROUP BY u.id, u.name, u.username
            ORDER BY cnt DESC, u.createdAt DESC
            LIMIT 10');
        $topCatalogs = array_map(
            static fn(array $row): array => [
                'userId' => (string) $row['userId'],
                'name' => (string) $row['name'],
                'username' => (string) $row['username'],
                'count' => (int) $row['cnt'],
            ],
            $topCatalogsStmt->fetchAll()
        );

        $topProductsStmt = $pdo->query('SELECT
            p.id AS productId,
            p.title,
            COUNT(ae.id) AS cnt
            FROM `AnalyticsEvent` ae
            INNER JOIN `Product` p ON p.id = ae.productId
            WHERE ae.createdAt >= ' . $periodSql . ' AND ae.eventType = \'WHATSAPP_CLICK\' AND ae.productId IS NOT NULL
            GROUP BY p.id, p.title
            ORDER BY cnt DESC, p.createdAt DESC
            LIMIT 10');
        $topProducts = array_map(
            static fn(array $row): array => [
                'productId' => (string) $row['productId'],
                'title' => (string) $row['title'],
                'count' => (int) $row['cnt'],
            ],
            $topProductsStmt->fetchAll()
        );

        $recentEventsStmt = $pdo->query('SELECT
            ae.id,
            ae.eventType,
            ae.path,
            ae.referrer,
            ae.createdAt,
            u.name AS ownerName,
            u.username AS ownerUsername,
            p.title AS productTitle
            FROM `AnalyticsEvent` ae
            INNER JOIN `User` u ON u.id = ae.ownerUserId
            LEFT JOIN `Product` p ON p.id = ae.productId
            WHERE ae.createdAt >= ' . $periodSql . '
            ORDER BY ae.createdAt DESC
            LIMIT 30');
        $recentEvents = array_map([self::class, 'serializeRecentEvent'], $recentEventsStmt->fetchAll());

        Http::json([
            'success' => true,
            'data' => [
                'pageViewsPerDay' => $pageViewsPerDay,
                'whatsappClicksPerDay' => $whatsappClicksPerDay,
                'topReferrers' => $topReferrers,
                'topCatalogs' => $topCatalogs,
                'topProducts' => $topProducts,
                'recentEvents' => $recentEvents,
            ],
        ]);
    }

    public static function userDetail(string $userId): never
    {
        $pdo = Db::pdo();

        $userStmt = $pdo->prepare('SELECT u.*, ua.email
            FROM `User` u
            LEFT JOIN `UserAccount` ua ON ua.userId = u.id
            WHERE u.id = ? LIMIT 1');
        $userStmt->execute([$userId]);
        $user = $userStmt->fetch();
        if (!$user) {
            Http::fail('User tidak ditemukan.', 404);
        }

        $productsStmt = $pdo->prepare('SELECT p.*, u.name AS ownerName, u.username AS ownerUsername
            FROM `Product` p
            INNER JOIN `User` u ON u.id = p.userId
            WHERE p.userId = ?
            ORDER BY p.createdAt DESC');
        $productsStmt->execute([$userId]);
        $products = array_map([MeController::class, 'serializeProduct'], $productsStmt->fetchAll());

        $dailyStmt = $pdo->prepare('SELECT
            DATE(createdAt) AS day,
            SUM(CASE WHEN eventType = \'PAGE_VIEW\' THEN 1 ELSE 0 END) AS views,
            SUM(CASE WHEN eventType = \'WHATSAPP_CLICK\' THEN 1 ELSE 0 END) AS whatsappClicks,
            SUM(CASE WHEN eventType = \'PRODUCT_VIEW\' THEN 1 ELSE 0 END) AS productViews
            FROM `AnalyticsEvent`
            WHERE ownerUserId = ? AND createdAt >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 DAY)
            GROUP BY DATE(createdAt)
            ORDER BY day ASC');
        $dailyStmt->execute([$userId]);

        $daily = [];
        foreach ($dailyStmt->fetchAll() as $row) {
            $daily[(string) $row['day']] = [
                'views' => (int) $row['views'],
                'whatsappClicks' => (int) $row['whatsappClicks'],
                'productViews' => (int) $row['productViews'],
            ];
        }

        $recentEventsStmt = $pdo->prepare('SELECT id, productId, eventType, path, referrer, createdAt
            FROM `AnalyticsEvent`
            WHERE ownerUserId = ?
            ORDER BY createdAt DESC
            LIMIT 20');
        $recentEventsStmt->execute([$userId]);
        $recentEvents = array_map(
            static fn(array $row): array => [
                'id' => (string) $row['id'],
                'productId' => $row['productId'] !== null ? (string) $row['productId'] : null,
                'eventType' => (string) $row['eventType'],
                'path' => (string) $row['path'],
                'referrer' => $row['referrer'] !== null ? (string) $row['referrer'] : null,
                'createdAt' => (string) $row['createdAt'],
            ],
            $recentEventsStmt->fetchAll()
        );

        Http::json([
            'success' => true,
            'data' => [
                'user' => MeController::serializeUser($user),
                'products' => $products,
                'totals' => MeController::analyticsSummary($userId),
                'daily' => $daily,
                'recentEvents' => $recentEvents,
            ],
        ]);
    }

    public static function listAuditLogs(): never
    {
        $limit = max(1, min(50, (int) (Http::query('limit', '20') ?? '20')));

        $stmt = Db::pdo()->query('SELECT
            al.id,
            al.action,
            al.targetType,
            al.targetId,
            al.metadata,
            al.createdAt,
            au.username AS adminUsername
            FROM `AuditLog` al
            INNER JOIN `AdminUser` au ON au.id = al.adminUserId
            ORDER BY al.createdAt DESC
            LIMIT ' . $limit);

        $rows = array_map([self::class, 'serializeAuditLog'], $stmt->fetchAll());

        Http::json([
            'success' => true,
            'data' => $rows,
        ]);
    }

    public static function createAuditLog(): never
    {
        $b = Http::body();
        $adminUserId = trim((string) ($b['adminUserId'] ?? ''));
        $action = trim((string) ($b['action'] ?? ''));
        $targetType = trim((string) ($b['targetType'] ?? ''));
        $targetId = trim((string) ($b['targetId'] ?? ''));

        if ($adminUserId === '' || $action === '' || $targetType === '' || $targetId === '') {
            Http::fail('adminUserId, action, targetType, dan targetId wajib diisi.', 400);
        }

        $metadata = isset($b['metadata']) && is_array($b['metadata']) ? $b['metadata'] : null;
        self::writeAuditLog($adminUserId, $action, $targetType, $targetId, $metadata);

        Http::json([
            'success' => true,
        ]);
    }

    private static function serializeAdmin(array $a): array
    {
        return [
            'id'        => $a['id'],
            'username'  => $a['username'],
            'role'      => $a['role'] ?? 'superadmin',
            'isActive'  => (bool) $a['isActive'],
            'createdAt' => $a['createdAt'] ?? null,
            'updatedAt' => $a['updatedAt'] ?? null,
        ];
    }

    private static function serializeUserListItem(array $row): array
    {
        return array_merge(
            MeController::serializeUser($row),
            [
                'productCount' => (int) ($row['productCount'] ?? 0),
                'views' => (int) ($row['views'] ?? 0),
                'whatsappClicks' => (int) ($row['whatsappClicks'] ?? 0),
            ]
        );
    }

    private static function serializeProductListItem(array $row): array
    {
        return array_merge(
            MeController::serializeProduct($row),
            [
                'views' => (int) ($row['views'] ?? 0),
                'clicks' => (int) ($row['clicks'] ?? 0),
            ]
        );
    }

    private static function serializeRecentEvent(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'eventType' => (string) $row['eventType'],
            'ownerName' => (string) $row['ownerName'],
            'ownerUsername' => (string) $row['ownerUsername'],
            'productTitle' => $row['productTitle'] !== null ? (string) $row['productTitle'] : null,
            'path' => (string) $row['path'],
            'referrer' => (string) ($row['referrer'] ?? 'Direct'),
            'createdAt' => (string) $row['createdAt'],
        ];
    }

    private static function serializeAuditLog(array $row): array
    {
        $metadata = null;
        if (!empty($row['metadata'])) {
            $decoded = json_decode((string) $row['metadata'], true);
            if (is_array($decoded)) {
                $metadata = $decoded;
            }
        }

        return [
            'id' => (string) $row['id'],
            'adminUsername' => (string) ($row['adminUsername'] ?? 'admin'),
            'action' => (string) $row['action'],
            'targetType' => (string) $row['targetType'],
            'targetId' => (string) $row['targetId'],
            'metadata' => $metadata,
            'createdAt' => (string) $row['createdAt'],
        ];
    }

    private static function normalizeDays(?string $value): int
    {
        $days = (int) ($value ?? '14');
        if ($days < 1) {
            return 14;
        }
        return min($days, 90);
    }

    private static function writeAuditLogSafe(
        string $adminUserId,
        string $action,
        string $targetType,
        string $targetId,
        ?array $metadata = null
    ): void {
        try {
            self::writeAuditLog($adminUserId, $action, $targetType, $targetId, $metadata);
        } catch (\Throwable) {
            // Audit log should not block the main request.
        }
    }

    private static function writeAuditLog(
        string $adminUserId,
        string $action,
        string $targetType,
        string $targetId,
        ?array $metadata = null
    ): void {
        $stmt = Db::pdo()->prepare('INSERT INTO `AuditLog`
            (`id`, `adminUserId`, `action`, `targetType`, `targetId`, `metadata`)
            VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            Utils::id(),
            $adminUserId,
            $action,
            $targetType,
            $targetId,
            $metadata ? json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
        ]);
    }
}
