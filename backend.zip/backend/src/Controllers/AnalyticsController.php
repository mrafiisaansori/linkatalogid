<?php
declare(strict_types=1);

namespace Linkatalog\Controllers;

use Linkatalog\Db;
use Linkatalog\Http;
use Linkatalog\Utils;

final class AnalyticsController
{
    public static function track(): never
    {
        $b = Http::body();
        $eventType = (string) ($b['eventType'] ?? '');
        $allowed = ['PAGE_VIEW','PRODUCT_VIEW','WHATSAPP_CLICK'];
        if (!in_array($eventType, $allowed, true)) {
            Http::fail('eventType invalid.', 400);
        }
        $ownerUserId = (string) ($b['ownerUserId'] ?? '');
        if ($ownerUserId === '') {
            Http::fail('ownerUserId required.', 400);
        }

        $referrer = isset($b['referrer']) ? trim((string) $b['referrer']) : '';
        $userAgent = isset($b['userAgent']) ? trim((string) $b['userAgent']) : '';
        $ipHash = isset($b['ipHash']) ? trim((string) $b['ipHash']) : '';
        $path = trim((string) ($b['path'] ?? ''));

        $stmt = Db::pdo()->prepare('INSERT INTO `AnalyticsEvent`
            (`id`, `eventType`, `ownerUserId`, `productId`, `path`, `referrer`, `userAgent`, `ipHash`)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            Utils::id(),
            $eventType,
            $ownerUserId,
            $b['productId'] ?? null,
            $path,
            $referrer !== '' ? substr($referrer, 0, 512) : null,
            $userAgent !== '' ? substr($userAgent, 0, 512) : null,
            $ipHash !== '' ? substr($ipHash, 0, 128) : null,
        ]);

        Http::json(['success' => true]);
    }
}
