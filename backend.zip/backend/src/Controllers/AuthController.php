<?php
declare(strict_types=1);

namespace Linkatalog\Controllers;

use Linkatalog\Db;
use Linkatalog\Http;
use Linkatalog\Mailer;
use Linkatalog\Utils;

final class AuthController
{
    private const CODE_TTL_MINUTES = 15;

    public static function checkUsername(): never
    {
        $username = Http::query('username', '') ?? '';
        $normalized = Utils::normalizeUsername($username);

        if ($normalized === '') {
            Http::json([
                'available'  => false,
                'normalized' => '',
                'message'    => 'Masukkan nama link minimal 1 karakter.',
            ]);
        }

        if (Utils::isReservedUsername($normalized)) {
            Http::json([
                'available'  => false,
                'normalized' => $normalized,
                'message'    => 'Link ini tidak tersedia. Coba pakai nama lain.',
            ]);
        }

        $stmt = Db::pdo()->prepare('SELECT id FROM `User` WHERE username = ? LIMIT 1');
        $stmt->execute([$normalized]);

        if ($stmt->fetch()) {
            Http::json([
                'available'  => false,
                'normalized' => $normalized,
                'message'    => 'Link ini sudah dipakai akun lain.',
            ]);
        }

        Http::json([
            'available'  => true,
            'normalized' => $normalized,
            'message'    => 'Link tersedia. Bisa langsung dipakai.',
        ]);
    }

    public static function signUp(): never
    {
        $body = Http::body();
        $name = trim((string) ($body['name'] ?? ''));
        $username = (string) ($body['username'] ?? '');
        $email = strtolower(trim((string) ($body['email'] ?? '')));
        $password = (string) ($body['password'] ?? '');
        $normalizedUsername = Utils::normalizeUsername($username);

        if ($name === '' || $normalizedUsername === '' || $email === '' || trim($password) === '') {
            Http::fail('Nama, link anda, email, dan password wajib diisi.', 400);
        }

        if (strlen(trim($password)) < 8) {
            Http::fail('Password minimal 8 karakter.', 400);
        }

        if (Utils::isReservedUsername($normalizedUsername)) {
            Http::fail('Link ini tidak tersedia. Coba pakai nama lain.', 409);
        }

        $pdo = Db::pdo();

        $stmt = $pdo->prepare('SELECT ua.id, ua.userId, ua.emailVerifiedAt, u.name
            FROM `UserAccount` ua
            INNER JOIN `User` u ON u.id = ua.userId
            WHERE ua.email = ? LIMIT 1');
        $stmt->execute([$email]);
        $existing = $stmt->fetch();

        if ($existing) {
            $stmt = $pdo->prepare('SELECT id FROM `User` WHERE username = ? AND id <> ? LIMIT 1');
            $stmt->execute([$normalizedUsername, $existing['userId']]);
        } else {
            $stmt = $pdo->prepare('SELECT id FROM `User` WHERE username = ? LIMIT 1');
            $stmt->execute([$normalizedUsername]);
        }
        if ($stmt->fetch()) {
            Http::fail('Link ini sudah dipakai akun lain.', 409);
        }

        if ($existing && $existing['emailVerifiedAt'] !== null) {
            Http::fail('Email ini sudah dipakai.', 409);
        }

        $code = Utils::verificationCode();
        $expiresAt = self::verificationExpiresAt();

        if ($existing) {
            $pdo->prepare('UPDATE `User`
                SET `name` = ?, `username` = ?, `bio` = ?, `themePreference` = ?, `themeAccent` = ?, `isActive` = 1
                WHERE `id` = ?')
                ->execute([
                    $name,
                    $normalizedUsername,
                    'Tambahkan bio singkat supaya calon pembeli langsung paham apa yang kamu jual.',
                    'light',
                    'emerald',
                    $existing['userId'],
                ]);

            $pdo->prepare('UPDATE `UserAccount`
                SET `passwordHash` = ?, `verificationCode` = ?, `verificationExpiresAt` = ?, `verificationSentAt` = ?, `emailVerifiedAt` = NULL
                WHERE `id` = ?')
                ->execute([
                    Utils::hashPassword($password),
                    $code,
                    $expiresAt,
                    self::dbNow(),
                    $existing['id'],
                ]);

            self::sendVerificationEmail($email, $name, $code);

            Http::json([
                'success' => false,
                'requiresVerification' => true,
                'email' => $email,
                'message' => 'Kode verifikasi sudah dikirim ke email kamu.',
            ], 202);
        }

        $userId = Utils::id();
        $accountId = Utils::id();
        $passwordHash = Utils::hashPassword($password);

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('INSERT INTO `User`
                (`id`, `name`, `username`, `bio`, `whatsapp`, `profileImage`, `location`, `themePreference`, `themeAccent`, `isActive`)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)');
            $stmt->execute([
                $userId,
                $name,
                $normalizedUsername,
                'Tambahkan bio singkat supaya calon pembeli langsung paham apa yang kamu jual.',
                '',
                '',
                '',
                'light',
                'emerald',
            ]);

            $stmt = $pdo->prepare('INSERT INTO `UserAccount`
                (`id`, `userId`, `email`, `passwordHash`, `emailVerifiedAt`, `verificationCode`, `verificationExpiresAt`, `verificationSentAt`)
                VALUES (?, ?, ?, ?, NULL, ?, ?, ?)');
            $stmt->execute([
                $accountId,
                $userId,
                $email,
                $passwordHash,
                $code,
                $expiresAt,
                self::dbNow(),
            ]);

            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            Http::fail('Gagal membuat akun.', 500, ['detail' => $e->getMessage()]);
        }

        self::sendVerificationEmail($email, $name, $code);

        Http::json([
            'success' => false,
            'requiresVerification' => true,
            'email' => $email,
            'message' => 'Kode verifikasi sudah dikirim ke email kamu.',
        ], 202);
    }

    public static function signIn(): never
    {
        $body = Http::body();
        $email = strtolower(trim((string) ($body['email'] ?? '')));
        $password = (string) ($body['password'] ?? '');

        if ($email === '' || trim($password) === '') {
            Http::fail('Email dan password wajib diisi.', 400);
        }

        $pdo = Db::pdo();
        $stmt = $pdo->prepare('SELECT ua.passwordHash, ua.emailVerifiedAt, u.id AS userId, u.isActive
            FROM `UserAccount` ua
            INNER JOIN `User` u ON u.id = ua.userId
            WHERE ua.email = ? LIMIT 1');
        $stmt->execute([$email]);
        $row = $stmt->fetch();

        if (!$row || (int) $row['isActive'] !== 1) {
            Http::fail('Email atau password belum cocok.', 401);
        }

        if (!Utils::verifyPassword($password, $row['passwordHash'])) {
            Http::fail('Email atau password belum cocok.', 401);
        }

        if ($row['emailVerifiedAt'] === null) {
            Http::json([
                'success' => false,
                'requiresVerification' => true,
                'email' => $email,
                'message' => 'Email belum diverifikasi. Masukkan kode verifikasi dulu.',
            ], 403);
        }

        Http::json([
            'success' => true,
            'message' => 'Berhasil masuk.',
            'user'    => MeController::buildSellerPayload($row['userId']),
        ]);
    }

    public static function verifyEmail(): never
    {
        $body = Http::body();
        $email = strtolower(trim((string) ($body['email'] ?? '')));
        $code = trim((string) ($body['code'] ?? ''));

        if ($email === '' || $code === '') {
            Http::fail('Email dan kode verifikasi wajib diisi.', 400);
        }

        $stmt = Db::pdo()->prepare('SELECT id, verificationCode, verificationExpiresAt, emailVerifiedAt
            FROM `UserAccount`
            WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $account = $stmt->fetch();

        if (!$account) {
            Http::fail('Akun tidak ditemukan.', 404);
        }

        if ($account['emailVerifiedAt'] !== null) {
            Http::json([
                'success' => true,
                'message' => 'Email sudah terverifikasi. Silakan masuk.',
            ]);
        }

        if ($account['verificationCode'] === null || !hash_equals((string) $account['verificationCode'], $code)) {
            Http::fail('Kode verifikasi belum cocok.', 400);
        }

        if ($account['verificationExpiresAt'] === null || strtotime((string) $account['verificationExpiresAt']) < time()) {
            Http::fail('Kode verifikasi sudah kedaluwarsa. Minta kirim ulang kode baru.', 400);
        }

        Db::pdo()->prepare('UPDATE `UserAccount`
            SET `emailVerifiedAt` = ?, `verificationCode` = NULL, `verificationExpiresAt` = NULL
            WHERE id = ?')
            ->execute([self::dbNow(), $account['id']]);

        Http::json([
            'success' => true,
            'message' => 'Verifikasi email berhasil. Sekarang kamu bisa masuk.',
        ]);
    }

    public static function resendVerification(): never
    {
        $body = Http::body();
        $email = strtolower(trim((string) ($body['email'] ?? '')));

        if ($email === '') {
            Http::fail('Email wajib diisi.', 400);
        }

        $stmt = Db::pdo()->prepare('SELECT ua.id, ua.emailVerifiedAt, u.name
            FROM `UserAccount` ua
            INNER JOIN `User` u ON u.id = ua.userId
            WHERE ua.email = ? LIMIT 1');
        $stmt->execute([$email]);
        $account = $stmt->fetch();

        if (!$account) {
            Http::fail('Akun tidak ditemukan.', 404);
        }

        if ($account['emailVerifiedAt'] !== null) {
            Http::json([
                'success' => true,
                'message' => 'Email sudah terverifikasi. Silakan langsung masuk.',
            ]);
        }

        $code = Utils::verificationCode();
        Db::pdo()->prepare('UPDATE `UserAccount`
            SET `verificationCode` = ?, `verificationExpiresAt` = ?, `verificationSentAt` = ?
            WHERE id = ?')
            ->execute([
                $code,
                self::verificationExpiresAt(),
                self::dbNow(),
                $account['id'],
            ]);

        self::sendVerificationEmail($email, (string) $account['name'], $code);

        Http::json([
            'success' => true,
            'message' => 'Kode verifikasi berhasil dikirim ulang.',
        ]);
    }

    private static function sendVerificationEmail(string $email, string $name, string $code): void
    {
        try {
            Mailer::sendVerificationCode($email, $name, $code);
        } catch (\Throwable $e) {
            Http::fail('Akun dibuat, tapi email verifikasi gagal dikirim. Coba kirim ulang kode beberapa saat lagi.', 500, [
                'detail' => $e->getMessage(),
            ]);
        }
    }

    private static function verificationExpiresAt(): string
    {
        return gmdate('Y-m-d H:i:s', time() + (self::CODE_TTL_MINUTES * 60));
    }

    private static function dbNow(): string
    {
        return gmdate('Y-m-d H:i:s');
    }
}
