<?php
declare(strict_types=1);

namespace Linkatalog\Controllers;

use Linkatalog\Db;
use Linkatalog\Http;
use Linkatalog\Utils;

final class MeController
{
    private const EMPTY_ANALYTICS = [
        'views' => 0,
        'whatsappClicks' => 0,
        'productViews' => 0,
    ];

    /** Hitung analytics summary untuk satu owner. */
    public static function analyticsSummary(string $userId): array
    {
        $pdo = Db::pdo();
        $stmt = $pdo->prepare('SELECT eventType, COUNT(*) AS cnt FROM `AnalyticsEvent`
            WHERE ownerUserId = ? GROUP BY eventType');
        $stmt->execute([$userId]);
        $rows = $stmt->fetchAll();
        $out = self::EMPTY_ANALYTICS;
        foreach ($rows as $r) {
            match ($r['eventType']) {
                'PAGE_VIEW'      => $out['views'] = (int) $r['cnt'],
                'WHATSAPP_CLICK' => $out['whatsappClicks'] = (int) $r['cnt'],
                'PRODUCT_VIEW'   => $out['productViews'] = (int) $r['cnt'],
                default          => null,
            };
        }
        return $out;
    }

    /** SellerSessionPayload — dipakai sign-in, sign-up, /me. */
    public static function buildSellerPayload(string $userId): ?array
    {
        $pdo = Db::pdo();

        $userStmt = $pdo->prepare('SELECT u.*, ua.email
            FROM `User` u
            INNER JOIN `UserAccount` ua ON ua.userId = u.id
            WHERE u.id = ? LIMIT 1');
        $userStmt->execute([$userId]);
        $user = $userStmt->fetch();
        if (!$user || (int) $user['isActive'] !== 1) {
            return null;
        }

        $productStmt = $pdo->prepare('SELECT p.*, u.name AS ownerName, u.username AS ownerUsername
            FROM `Product` p
            INNER JOIN `User` u ON u.id = p.userId
            WHERE p.userId = ? ORDER BY p.createdAt DESC');
        $productStmt->execute([$userId]);
        $products = $productStmt->fetchAll();

        return [
            'authenticated' => true,
            'user' => self::serializeUser($user),
            'products' => array_map([self::class, 'serializeProduct'], $products),
            'analytics' => self::analyticsSummary($userId),
        ];
    }

    public static function serializeUser(array $u): array
    {
        return [
            'id'              => $u['id'],
            'name'            => $u['name'],
            'username'        => $u['username'],
            'email'           => $u['email'] ?? null,
            'bio'             => $u['bio'],
            'whatsapp'        => $u['whatsapp'],
            'profileImage'    => $u['profileImage'],
            'location'        => $u['location'],
            'themePreference' => $u['themePreference'],
            'themeAccent'     => $u['themeAccent'],
            'isActive'        => (bool) $u['isActive'],
            'createdAt'       => $u['createdAt'],
            'updatedAt'       => $u['updatedAt'],
        ];
    }

    public static function serializeProduct(array $p): array
    {
        return [
            'id'          => $p['id'],
            'userId'      => $p['userId'],
            'ownerName'   => $p['ownerName'] ?? null,
            'ownerUsername' => $p['ownerUsername'] ?? null,
            'title'       => $p['title'],
            'price'       => (int) $p['price'],
            'description' => $p['description'],
            'imageUrl'    => $p['imageUrl'],
            'badge'       => $p['badge'],
            'category'    => $p['category'],
            'isActive'    => (bool) $p['isActive'],
            'createdAt'   => $p['createdAt'],
            'updatedAt'   => $p['updatedAt'],
        ];
    }

    public static function me(): never
    {
        $userId = Http::query('userId');
        if (!$userId) {
            Http::fail('userId required.', 400);
        }
        $payload = self::buildSellerPayload($userId);
        if (!$payload) {
            Http::json([
                'authenticated' => false,
                'user' => null,
                'products' => [],
                'analytics' => self::EMPTY_ANALYTICS,
            ]);
        }
        Http::json($payload);
    }

    public static function updateProfile(string $userId): never
    {
        $body = Http::body();
        $pdo = Db::pdo();

        $userStmt = $pdo->prepare('SELECT id, username FROM `User` WHERE id = ? LIMIT 1');
        $userStmt->execute([$userId]);
        $existing = $userStmt->fetch();
        if (!$existing) {
            Http::fail('User tidak ditemukan.', 404);
        }

        $allowed = ['name','bio','whatsapp','profileImage','location','themePreference','themeAccent','username'];
        $sets = [];
        $params = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) {
                $value = (string) $body[$f];
                if ($f === 'username') {
                    $value = Utils::normalizeUsername($value);
                    if ($value === '') {
                        Http::fail('Link katalog wajib diisi.', 400);
                    }
                    if (Utils::isReservedUsername($value)) {
                        Http::fail('Link ini tidak tersedia. Coba pakai nama lain.', 409);
                    }

                    $usernameStmt = $pdo->prepare('SELECT id FROM `User` WHERE username = ? AND id <> ? LIMIT 1');
                    $usernameStmt->execute([$value, $userId]);
                    if ($usernameStmt->fetch()) {
                        Http::fail('Link ini sudah dipakai akun lain.', 409);
                    }
                }

                if ($f === 'themePreference' && !in_array($value, ['light', 'dark'], true)) {
                    Http::fail('Tema tidak valid.', 400);
                }

                if ($f === 'themeAccent' && !in_array($value, ['emerald', 'sky', 'coral', 'amber'], true)) {
                    Http::fail('Aksen tema tidak valid.', 400);
                }

                $sets[] = "`$f` = ?";
                $params[] = $value;
            }
        }
        if (!$sets) {
            Http::fail('Tidak ada field yang dikirim.', 400);
        }
        $params[] = $userId;
        $sql = 'UPDATE `User` SET ' . implode(', ', $sets) . ' WHERE id = ?';
        $pdo->prepare($sql)->execute($params);

        $payload = self::buildSellerPayload($userId);
        if (!$payload || !$payload['user']) {
            Http::fail('User tidak ditemukan.', 404);
        }

        Http::json([
            'success' => true,
            'message' => 'Profil berhasil diperbarui.',
            'data' => $payload['user'],
        ]);
    }

    public static function listProducts(string $userId): never
    {
        $stmt = Db::pdo()->prepare('SELECT p.*, u.name AS ownerName, u.username AS ownerUsername
            FROM `Product` p
            INNER JOIN `User` u ON u.id = p.userId
            WHERE p.userId = ? ORDER BY p.createdAt DESC');
        $stmt->execute([$userId]);
        $rows = array_map([self::class, 'serializeProduct'], $stmt->fetchAll());
        Http::json(['success' => true, 'data' => $rows]);
    }

    public static function createProduct(string $userId): never
    {
        $b = Http::body();
        $title = trim((string) ($b['title'] ?? ''));
        $description = trim((string) ($b['description'] ?? ''));
        $category = trim((string) ($b['category'] ?? ''));
        $imageUrl = trim((string) ($b['imageUrl'] ?? ''));
        if ($title === '') {
            Http::fail('Title wajib diisi.', 400);
        }
        if ($description === '' || $category === '' || $imageUrl === '') {
            Http::fail('Deskripsi, kategori, dan gambar wajib diisi.', 400);
        }

        $pdo = Db::pdo();
        $userStmt = $pdo->prepare('SELECT username FROM `User` WHERE id = ? LIMIT 1');
        $userStmt->execute([$userId]);
        $user = $userStmt->fetch();
        if (!$user) {
            Http::fail('User not found.', 404);
        }

        $id = Utils::slugifyProductId($user['username'], $title);
        $checkStmt = $pdo->prepare('SELECT id FROM `Product` WHERE id = ? LIMIT 1');
        $checkStmt->execute([$id]);
        if ($checkStmt->fetch()) {
            $id .= '-' . substr(bin2hex(random_bytes(3)), 0, 6);
        }

        $stmt = $pdo->prepare('INSERT INTO `Product`
            (`id`, `userId`, `title`, `price`, `description`, `imageUrl`, `badge`, `category`, `isActive`)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $id, $userId, $title,
            (int) ($b['price'] ?? 0),
            $description,
            $imageUrl,
            (string) ($b['badge'] ?? ''),
            $category,
            isset($b['isActive']) ? (!empty($b['isActive']) ? 1 : 0) : 1,
        ]);

        $fetch = $pdo->prepare('SELECT p.*, u.name AS ownerName, u.username AS ownerUsername
            FROM `Product` p
            INNER JOIN `User` u ON u.id = p.userId
            WHERE p.id = ? LIMIT 1');
        $fetch->execute([$id]);
        Http::json(['success' => true, 'data' => self::serializeProduct($fetch->fetch())]);
    }

    public static function updateProduct(string $userId, string $productId): never
    {
        $b = Http::body();
        $allowed = ['title','price','description','imageUrl','badge','category','isActive'];
        $sets = [];
        $params = [];
        foreach ($allowed as $f) {
            if (!array_key_exists($f, $b)) {
                continue;
            }
            if (in_array($f, ['title', 'description', 'imageUrl', 'category'], true) && trim((string) $b[$f]) === '') {
                Http::fail('Judul, deskripsi, kategori, dan gambar wajib diisi.', 400);
            }
            $sets[] = "`$f` = ?";
            if ($f === 'price') {
                $params[] = (int) $b[$f];
            } elseif ($f === 'isActive') {
                $params[] = !empty($b[$f]) ? 1 : 0;
            } else {
                $params[] = (string) $b[$f];
            }
        }
        if (!$sets) {
            Http::fail('Tidak ada field yang dikirim.', 400);
        }
        $params[] = $productId;
        $params[] = $userId;
        $sql = 'UPDATE `Product` SET ' . implode(', ', $sets) . ' WHERE id = ? AND userId = ?';
        $count = Db::pdo()->prepare($sql);
        $count->execute($params);
        if ($count->rowCount() === 0) {
            Http::fail('Produk tidak ditemukan.', 404);
        }
        $fetch = Db::pdo()->prepare('SELECT p.*, u.name AS ownerName, u.username AS ownerUsername
            FROM `Product` p
            INNER JOIN `User` u ON u.id = p.userId
            WHERE p.id = ? LIMIT 1');
        $fetch->execute([$productId]);
        Http::json(['success' => true, 'data' => self::serializeProduct($fetch->fetch())]);
    }

    public static function deleteProduct(string $userId, string $productId): never
    {
        $stmt = Db::pdo()->prepare('DELETE FROM `Product` WHERE id = ? AND userId = ?');
        $stmt->execute([$productId, $userId]);
        if ($stmt->rowCount() === 0) {
            Http::fail('Produk tidak ditemukan.', 404);
        }
        Http::json(['success' => true]);
    }

    public static function toggleProduct(string $userId, string $productId): never
    {
        $stmt = Db::pdo()->prepare('UPDATE `Product` SET `isActive` = 1 - `isActive` WHERE id = ? AND userId = ?');
        $stmt->execute([$productId, $userId]);
        if ($stmt->rowCount() === 0) {
            Http::fail('Produk tidak ditemukan.', 404);
        }
        $fetch = Db::pdo()->prepare('SELECT p.*, u.name AS ownerName, u.username AS ownerUsername
            FROM `Product` p
            INNER JOIN `User` u ON u.id = p.userId
            WHERE p.id = ? LIMIT 1');
        $fetch->execute([$productId]);
        Http::json(['success' => true, 'data' => self::serializeProduct($fetch->fetch())]);
    }
}
