<?php
declare(strict_types=1);

namespace Linkatalog\Controllers;

use Linkatalog\Db;
use Linkatalog\Http;
use Linkatalog\Utils;

final class PublicController
{
    public static function catalog(string $username): never
    {
        $username = Utils::normalizeUsername($username);
        if ($username === '') {
            Http::fail('Username invalid.', 400);
        }

        $pdo = Db::pdo();
        $stmt = $pdo->prepare('SELECT * FROM `User` WHERE username = ? AND isActive = 1 LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if (!$user) {
            Http::fail('Katalog tidak ditemukan.', 404);
        }

        $productStmt = $pdo->prepare('SELECT p.*, u.name AS ownerName, u.username AS ownerUsername
            FROM `Product` p
            INNER JOIN `User` u ON u.id = p.userId
            WHERE p.userId = ? AND p.isActive = 1 ORDER BY p.createdAt DESC');
        $productStmt->execute([$user['id']]);
        $products = $productStmt->fetchAll();

        Http::json([
            'success' => true,
            'user' => MeController::serializeUser($user),
            'products' => array_map([MeController::class, 'serializeProduct'], $products),
            'analytics' => MeController::analyticsSummary($user['id']),
        ]);
    }
}
