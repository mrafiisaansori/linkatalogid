<?php
declare(strict_types=1);

namespace Linkatalog;

final class Http
{
    public static function json(array $data, int $status = 200): never
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=utf-8');
            self::corsHeaders();
        }
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function corsHeaders(): void
    {
        $origin = Bootstrap::get('cors_origin');
        if (is_string($origin) && $origin !== '') {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Vary: Origin');
            header('Access-Control-Allow-Headers: Authorization, Content-Type');
            header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
            header('Access-Control-Allow-Credentials: true');
        }
    }

    public static function body(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    public static function query(string $key, ?string $default = null): ?string
    {
        $value = $_GET[$key] ?? $default;
        return is_string($value) ? $value : $default;
    }

    public static function ok(array $data = [], string $message = ''): never
    {
        self::json(['success' => true, 'message' => $message, 'data' => $data]);
    }

    public static function fail(string $message, int $status = 400, array $extra = []): never
    {
        self::json(array_merge(['success' => false, 'message' => $message], $extra), $status);
    }
}
