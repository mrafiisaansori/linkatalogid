<?php
declare(strict_types=1);

namespace Linkatalog;

final class Mailer
{
    public static function sendVerificationCode(string $toEmail, string $recipientName, string $code): void
    {
        $cfg = Bootstrap::get('smtp', []);
        $host = trim((string) ($cfg['host'] ?? ''));
        $port = (int) ($cfg['port'] ?? 465);
        $secure = trim((string) ($cfg['secure'] ?? 'ssl'));
        $username = trim((string) ($cfg['username'] ?? ''));
        $password = (string) ($cfg['password'] ?? '');
        $fromEmail = trim((string) ($cfg['from_email'] ?? $username));
        $fromName = trim((string) ($cfg['from_name'] ?? 'Linkatalog'));

        if ($host === '' || $username === '' || $password === '' || $fromEmail === '') {
            throw new \RuntimeException('SMTP belum dikonfigurasi.');
        }

        $transport = $secure === 'ssl' ? 'ssl://' . $host : $host;
        $socket = @stream_socket_client(
            $transport . ':' . $port,
            $errno,
            $errstr,
            20,
            STREAM_CLIENT_CONNECT
        );

        if (!$socket) {
            throw new \RuntimeException('Gagal connect ke SMTP: ' . $errstr . ' (' . $errno . ')');
        }

        stream_set_timeout($socket, 20);

        try {
            self::expect($socket, [220]);
            self::command($socket, 'EHLO ' . self::ehloHost(), [250]);
            self::command($socket, 'AUTH LOGIN', [334]);
            self::command($socket, base64_encode($username), [334]);
            self::command($socket, base64_encode($password), [235]);
            self::command($socket, 'MAIL FROM:<' . $fromEmail . '>', [250]);
            self::command($socket, 'RCPT TO:<' . $toEmail . '>', [250, 251]);
            self::command($socket, 'DATA', [354]);

            $subject = 'Kode verifikasi Linkatalog';
            $plainText = self::plainMessage($recipientName, $code);
            $html = self::htmlMessage($recipientName, $code);
            $headers = [
                'From: ' . self::formatAddress($fromEmail, $fromName),
                'To: ' . self::formatAddress($toEmail, $recipientName),
                'Subject: =?UTF-8?B?' . base64_encode($subject) . '?=',
                'MIME-Version: 1.0',
                'Content-Type: text/html; charset=UTF-8',
                'Content-Transfer-Encoding: 8bit'
            ];

            $body = implode("\r\n", $headers)
                . "\r\n\r\n"
                . $html
                . "\r\n\r\n<!-- fallback: " . htmlspecialchars($plainText, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . " -->\r\n.";

            fwrite($socket, $body . "\r\n");
            self::expect($socket, [250]);
            self::command($socket, 'QUIT', [221]);
        } finally {
            fclose($socket);
        }
    }

    private static function plainMessage(string $recipientName, string $code): string
    {
        $name = trim($recipientName) !== '' ? $recipientName : 'teman';
        return "Halo {$name}, kode verifikasi Linkatalog kamu adalah {$code}. Kode ini berlaku 15 menit.";
    }

    private static function htmlMessage(string $recipientName, string $code): string
    {
        $name = htmlspecialchars(trim($recipientName) !== '' ? $recipientName : 'teman', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $safeCode = htmlspecialchars($code, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        return <<<HTML
<!doctype html>
<html lang="id">
  <body style="margin:0;padding:24px;background:#f8fafc;font-family:Arial,sans-serif;color:#0f172a;">
    <div style="max-width:560px;margin:0 auto;background:#ffffff;border:1px solid #e2e8f0;border-radius:20px;padding:32px;">
      <p style="margin:0 0 12px;font-size:14px;color:#64748b;">Linkatalog</p>
      <h1 style="margin:0 0 16px;font-size:28px;line-height:1.2;">Kode verifikasi email kamu</h1>
      <p style="margin:0 0 20px;font-size:15px;line-height:1.7;">Halo {$name}, masukkan kode di bawah ini untuk mengaktifkan akun Linkatalog kamu.</p>
      <div style="margin:0 0 20px;padding:18px 20px;border-radius:16px;background:#ecfeff;border:1px solid #99f6e4;text-align:center;">
        <span style="display:block;font-size:34px;letter-spacing:10px;font-weight:700;color:#0f766e;">{$safeCode}</span>
      </div>
      <p style="margin:0;font-size:14px;line-height:1.7;color:#475569;">Kode ini berlaku selama 15 menit. Kalau kamu tidak merasa mendaftar di Linkatalog, abaikan email ini.</p>
    </div>
  </body>
</html>
HTML;
    }

    private static function formatAddress(string $email, string $name): string
    {
        $safeName = str_replace(['"', "\r", "\n"], ['', '', ''], $name);
        return sprintf('"%s" <%s>', $safeName, $email);
    }

    private static function ehloHost(): string
    {
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        return preg_replace('/[^a-z0-9.-]+/i', '', (string) $host) ?: 'localhost';
    }

    private static function command($socket, string $command, array $expectedCodes): void
    {
        fwrite($socket, $command . "\r\n");
        self::expect($socket, $expectedCodes);
    }

    private static function expect($socket, array $expectedCodes): void
    {
        $response = '';
        while (!feof($socket)) {
            $line = fgets($socket, 515);
            if ($line === false) {
                break;
            }
            $response .= $line;
            if (strlen($line) >= 4 && $line[3] === ' ') {
                break;
            }
        }

        $code = (int) substr($response, 0, 3);
        if (!in_array($code, $expectedCodes, true)) {
            throw new \RuntimeException('SMTP response tidak valid: ' . trim($response));
        }
    }
}
