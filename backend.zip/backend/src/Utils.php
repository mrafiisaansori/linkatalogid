<?php
declare(strict_types=1);

namespace Linkatalog;

final class Utils
{
    public const RESERVED_USERNAMES = [
        'admin', 'be-admin', 'api', 'auth', 'dashboard', 'login', 'logout',
        'register', 'signup', 'signin', 'public', 'me', 'analytics', 'settings',
        'profile', 'products', 'users', 'app', 'static', 'assets', 'image',
        'images', 'cdn', 'www', 'help', 'support', 'about', 'contact',
    ];

    /** Generate 25-char cuid-like id (waktu base36 + random base36). */
    public static function id(): string
    {
        $time = base_convert((string) (int) (microtime(true) * 1000), 10, 36);
        $rand = bin2hex(random_bytes(8));
        return strtolower(substr('c' . $time . $rand, 0, 25));
    }

    public static function normalizeUsername(string $value): string
    {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9-]+/', '-', $value) ?? '';
        $value = preg_replace('/-+/', '-', $value) ?? '';
        return trim($value, '-');
    }

    public static function isReservedUsername(string $value): bool
    {
        $normalized = self::normalizeUsername($value);
        return $normalized === '' || in_array($normalized, self::RESERVED_USERNAMES, true);
    }

    public static function nowIso(): string
    {
        return (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.v\Z');
    }

    public static function hashPassword(string $plain): string
    {
        return password_hash($plain, PASSWORD_BCRYPT, ['cost' => 10]);
    }

    public static function verifyPassword(string $plain, string $hash): bool
    {
        return password_verify($plain, $hash);
    }

    public static function slugifyProductId(string $username, string $title): string
    {
        $slug = strtolower($title);
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug) ?? '';
        $slug = trim($slug, '-');
        return $username . '-' . $slug;
    }

    public static function verificationCode(): string
    {
        return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }
}
